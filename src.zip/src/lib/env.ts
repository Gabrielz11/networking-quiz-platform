import { z } from "zod";

const envSchema = z.object({
    DATABASE_URL: z.string().url(),
    GEMINI_API_KEY: z.string().min(1),
    GEMINI_MODEL: z.string().default("gemini-2.5-flash"),
    GEMINI_PRO_MODEL: z.string().default("gemini-2.5-flash"),
    GROQ_FALLBACK_MODEL: z.string().default("llama-3.1-8b-instant"),
    REASONING_FALLBACK_MODEL: z.string().default("llama-3.3-70b-versatile"),
    EXPLANATION_MODEL: z.string().default("llama-3.1-8b-instant"),
    // Obrigatória apenas quando EMBEDDING_PROVIDER=openai (padrão)
    OPENAI_API_KEY: z.string().min(1).optional(),
    GROQ_API_KEY: z.string().min(1),
    COHERE_API_KEY: z.string().optional(),
    REDIS_URL: z.string().default("redis://localhost:6379"),
    RAG_RETRIEVAL_LIMIT: z.string().default("20").transform(Number),
    RAG_FINAL_CONTEXT_LIMIT: z.string().default("5").transform(Number),
    RAG_CHUNK_SIZE: z.string().default("1200").transform(Number),
    RAG_CHUNK_OVERLAP: z.string().default("200").transform(Number),
    UPLOAD_DIR: z.string().default("./storage/uploads"),
    EMBEDDING_PROVIDER: z.enum(["openai", "gemini"]).default("openai"),
    EMBEDDING_MODEL: z.string().default("text-embedding-3-small"),
    TEACHER_REGISTRATION_KEY: z.string().optional(),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
    console.error("❌ Erro de configuração nas variáveis de ambiente:", parsed.error.format());
    throw new Error("Variáveis de ambiente inválidas.");
}

export const env = parsed.data;
